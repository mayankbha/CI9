<div id="page_body">
<div class="inner">
<h1>Sign Up <span>(Company)</span></h1>
<?=$content ?>
<form action="" method="post">
<div class="signup_form">
<div class="left">

<p>
<span>First Name:</span>
<input name="" type="text" class="input_field" />
</p>

<p>
<span>Last Name:</span>
<input name="" type="text" class="input_field" />
</p>

<p>
<span>Email:</span>
<input name="" type="text" class="input_field" />
</p>

<p>
<span>Address:</span>
<input name="" type="text" class="input_field" />
</p>

<p>
<span>Address 2:</span>
<input name="" type="text" class="input_field" />
</p>

<p class="company_terms">
<label><input name="" type="checkbox" value="" />
I Agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
</label>
</p>

</div>	<!-- end left container here -->

<div class="right">

<p>
<span>City:</span>
<input name="" type="text" class="input_field" />
</p>

<div class="states">
<p style="float:left;">
<span>State:</span>
<select name="" class="input_field" style="width:240px;">
<option>Select</option>
</select>
</p>

<p style="float:right">
<span>Zip Code:</span>
<input name="" type="text" class="input_field" style="width:155px;" />
</p>
<div class="clear"></div>
</div>

<p>
<span>Phone Number:</span>
<input name="" type="text" class="input_field" />
</p>

<p>
<span>Password:</span>
<input name="" type="password" class="input_field" />
</p>

<p>
<span>Confirm Password:</span>
<input name="" type="password" class="input_field" />
</p>

</div>	<!-- end right container here -->

<div class="clear"></div>

<div align="center" style="padding:30px 0 30px 0;">
<input name="" type="submit" class="btn" value="Submit" />&nbsp;
<input name="" type="submit" class="btn" value="Cancel" />
</div>

</div>	<!-- end signup form here -->
</form>

</div>	<!-- end body contents -->
</div>	<!-- end page body here -->
