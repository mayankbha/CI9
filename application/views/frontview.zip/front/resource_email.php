<div id="popover" style="width:570px;">




<div id="popover-head" class="clearfix">

<div class="span3"><img src="<?=base_url();?>images/front/popup-logo.png" alt=" "></div>

<div class="close-pp"><a href="javascript:void(0)" onClick="closePP();">Close (<strong>x</strong>)</a></div>

</div>	<!-- end popover head -->



<div id="popover-body">

<div class="popover-heading clearfix">

<h3>Share with Email</h3>



</div>



<form class="share-form rchrch_share">

<label>Send To:</label>

<input name="" type="text" class="input_field" value="Please fill in email addresses seperated by coma">

<label>Subject:</label>

<input name="" type="text" class="input_field" value="Lorem Ipsum Dpolor">

<label>Message:</label>

<div class="share-detail share_dtl_twt">
<textarea name="" cols="10" rows="10" class=" input_field" >Say something about this...</textarea>
<a href="#">http://www.LoremIpsumDpolor.com/index.php?</a>
</div>

<div class="submit-form">
  
  
  
  <input name="" type="button" class="custom-btn" value="Share">

<input name="" type="button" class="custom-btn" value="Cancel" onClick="closePP();">

</div>

</form>



</div>	<!-- end popver body -->



</div>