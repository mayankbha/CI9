<div id="footer">

	<div class="container">
	
		<div class="row">
		
			<div class="span3">
				<a href="<?php echo site_url('about');?>">About Us</a> 
				<a href="<?php echo site_url('terms');?>">Terms of Use</a> 
				<a href="<?php echo site_url('privacy');?>">Privacy Policy</a>
			</div>
			
			<div class="span3">
				<a href="<?php echo site_url('contribute');?>">Contribute</a> 
				<a href="<?php echo site_url('partners');?>">Partners</a> 
				<a href="<?php echo site_url('guidelines');?>">Guidelines</a> 
				<a href="<?php echo site_url('jobs');?>">Jobs</a>
			</div>
			
			<div class="span3">
				<a href="<?php echo site_url('press');?>">Press</a> 
				<a href="<?php echo site_url('blog');?>">Blog</a> 
				<a href="<?php echo site_url('contact');?>">Contact</a> 
				<a href="#">Facebook</a> 
				<a href="#">Twitter</a>
			</div>
			
			<div class="span3 text-right">&copy; 2013 Startup Meow. All Rights Reserved.</div>
		
		</div>
	
	</div>

</div>