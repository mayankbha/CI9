<div id="page-body">

<div class="container">

<div class="inner-contents">

<div class="row">

<div class="span12">
<h2><span><img src="<?=base_url();?>images/front/message-center-ico.gif" alt=""> View Message Detail</span></h2>
</div>

</div>
<!--/row -->

<!--message center -->
<div class="message-center">
<ul class="message-tabs">
<li class="active"><a href="#">Inbox</a></li>
<li><a href="#">Send a Message</a></li>
</ul>
<div class="clear"></div>
<!--message content -->
<div class="inbox-content">
<div class="row-fluid">
<div class="message-form view-message-detail">
<p><label>From:</label> <span>Username</span></p>
<p><label>Subject:</label> <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit."</span></p>
<p><label>Message:</label> <span style="width: 92%; float: right">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam venenatis elit enim, vitae dictum lacus dapibus et. Donec lacinia commodo odio, non rhoncus sem adipiscing id. Curabitur eros dolor, lacinia hendrerit lorem euismod, aliquam consequat risus. Nam semper lacus metus, tincidunt cursus nisi elementum ut. Phasellus eleifend nulla id tristique semper. Curabitur pretium consequat tortor sit amet hendrerit. Phasellus posuere dolor vitae enim facilisis, sit amet varius dolor elementum. Donec pellentesque mauris metus, et posuere ante ultrices vel. Aliquam in nibh euismod eros venenatis volutpat vel a mauris. Pellentesque nunc justo, pharetra vel sodales ut, mattis non diam. Donec et risus non metus porttitor dictum porttitor in mi. Curabitur eu dolor ut quam posuere auctor sed eu diam. Mauris auctor eros at hendrerit scelerisque. Suspendisse feugiat dignissim felis, non convallis purus auctor in. Nam ante justo, sagittis eget posuere sed, dignissim eget tortor. Etiam congue urna vitae justo euismod sollicitudin.</span></p>
<div class="clear"></div>
<p><span style="display: block; margin-top: 15px;" class="text-center">
<button class="btn btn-primary" type="submit">Back</button>
<button class="btn btn-primary" type="submit">Reply</button>
<button class="btn btn-primary" type="submit">Remove</button>
</span></p>
</div>
</div>
<!--/row -->

</div>
<!--/message content -->

</div>
<!--/message center -->

</div>
</div>

</div>	<!-- end page body -->

<div id="push"></div>
