<div id="page-body">

<div class="container">


<div class="row-fluid inner-content">

<!--section left -->
<div class="span8 inner-contents">

<h2><span><img src="<?=base_url();?>images/front/edit_ac_icon.png" alt="Edit My Account"> Edit My Account</span></h2>

<div class="contact-form edit_my_account">

<div class="comment_box comment_box_confirm" style="margin-bottom: 16px; margin-top: 16px;display:none;" >

<?=$content;?>

  <a href="javascript:void(0);" onclick="$('.comment_box_confirm').hide();" class="comment-close" style="right:-6px; top:-6px;"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt=""></a>

</div>

<div class="row-fluid">
<form action="#" method="get">
	<div class="span6">
	  <p> <strong>First Name:</strong>
		<input name="" type="text" class="input_field" value="Lorem">
	  </p>
	  <p> <strong>Last Name:</strong>
		<input name="" type="text" class="input_field" value="Ipsum">
	  </p>
	  <p> <strong>Email Address:</strong>
		<input name="" type="text" class="input_field" value="lorem@ipsum.com">
	  </p>
	  <p> <strong>Upload Image:</strong> <span class="upload_spa">
		<input name="" type="text" class="input_field" value="">
		</span>
		<input name="" type="button" class="custom-btn" value="Browse">
	  </p>
	</div>
	<div class="span6">
	  <p> <strong>Linkedin Account:</strong>
		<input name="" type="text" class="input_field" value="http://www.loremipsum.com/linked.php?">
	  </p>
	  <p> <strong>Twitter Account:</strong>
		<input name="" type="text" class="input_field" value="http://www.loremipsum.com/twitter.php?">
	  </p>
	  <p> <strong>Facebook Account:</strong>
		<input name="" type="text" class="input_field" value="http://www.loremipsum.com/facebook.php?">
	  </p>
	  <p> <strong>Website URL:</strong>
		<input name="" type="text" class="input_field" value="www.Loremipsum.com">
	  </p>
	</div>
	<div class="span12">
	  <p> <strong>About:</strong>
		<textarea class="input_field">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining </textarea>
	  </p>
	<!--  <p style="padding-top:5px;"> <strong class="">
		<input type="checkbox" value="asdf" checked>
		Send weekly To-Do reminders</strong> </p>
	  <p> <strong class="">
		<input type="checkbox" value="asdf" checked>
		Send Recommendations</strong> </p>-->
	</div>
	<div class="submit text-center clear">
	  <input name="" type="button" class="custom-btn" value="Save">
	  <input name="" type="button" class="custom-btn" value="Cancel">
	</div>
  </form>
</div>
</div>
<!--  end edit ac form  -->

</div>
<!--/section left -->



<!--section right -->
<div class="span4">

<div class="data-box">

<div class="todo-title">
<h3><img src="<?=base_url();?>images/front/todo-sidebar-icon.png" alt=""> To-Do</h3>
</div>
<!--tabs -->
<ul class="tabs-list">
<li class="active"><a href="#">Priorities</a></li>
<li><a href="#">Daily</a></li>
<li><a href="#">Weekly</a></li>
<li><a href="#">Monthly</a></li>
<li><a href="#">Quarterly</a></li>
<li><a href="#">Yearly</a></li>

</ul>
<!--/tabs -->
<!--buttons scroll container -->
<div class="buttons-container">
<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->

<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->

<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->


<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->


<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->


<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->


<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->


<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->

<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->

<!--buttons bar -->
<div class="buttons-bar">
<p class="checkbox-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="buttons-area">
<p><span class="button-field pull-left"><button class="pull-right">Checklist</button></span> <span class="button-field pull-right"><button>Lesson</button></span> <br class="clear" /></p>
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>
<!--/buttons bar -->

</div>
<!--scroll container -->
</div>
<!--sidebar box -->
<div class="sidebar-box">
<div class="yellow-title"><h3><img src="<?=base_url();?>images/front/recommendation-bg.png" width="26" height="30" alt=""> Recommendations</h3>
</div>
<div class="buttons-container" style="height: 220px;">
<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

<div class="sidebar-buttons-bar">
<p class="sidebar-box-title"><input name="" type="checkbox" value="" class="check-box"> <label>Set Up Your Landing Page</label></p>
<div class="sidebar-buttons-area">
<p><span class="button-field pull-left text-right"><a href="#">Do not need to</a></span> <span class="button-field pull-right"><a href="#">Do not want to</a></span> <br class="clear" /></p>
</div>
</div>

</div>

</div>
<!--/sidebar box -->

<!--sidebar box -->
<div class="sidebar-box">
<div class="check-title"><h3 class="pull-left"><img src="<?=base_url();?>images/front/checklist-image.png" width="29" height="29" alt=""> Checklist</h3> <span class="checklist-search"><input name="" type="text" class="input-field"><input name="" type="submit" class="checklist-submit"></span>
</div>
<div class="buttons-container" style="height: 220px;">
<div class="checklist-titles">
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
<h2>Lorem Ipsum Dolor Title Here</h2>
</div>

</div>

</div>
<!--/sidebar box -->


</div>
<!--/section right -->
</div>





<!--/content row -->

</div>

	<!-- end lesson detail -->

</div>
<div id="push"></div>