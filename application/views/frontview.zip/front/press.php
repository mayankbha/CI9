<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents">

<h2><span class="press-ico">Press</span></h2>



<div class="contact-form" style="padding-bottom:10px;">

<div class="row-fluid">



<div class="span6">

<div class=""><?=str_replace('<p>','',str_replace('</p>','',str_replace('<img','<img class="img_brdr" style="margin:15px 20px 0 0"',$image)));?></div>

<p style="padding-top:15px;"></p>
<?=$content;?>

</div>	<!-- end left container -->



<div class="span6">

<form>

<p>

<strong>Name:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Publication:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Email:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Subject:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Message:</strong>

<textarea name="" cols="10" rows="10" class="input_field"></textarea>

</p>



<div class="submit text-center">

<input name="" type="button" class="custom-btn" value="Get in Touch" style="background:url(<?=base_url();?>images/front/btn-large.png) no-repeat scroll left top;width:148px;">

<input name="" type="button" class="custom-btn" value="Cancel">

</div>

</form>

</div>	<!-- end right container -->



</div>

</div>	<!-- end container form -->



<div class="PR-cont">

<div class="PR-header clearfix">

<h4 class="pull-left"><?=strip_tags($press_new_title_1);?></h4>

<div class="pull-right"><?=strip_tags($press_new_date_1);?></div>

</div>

<?=$press_new_content_1;?>

</div>	<!-- end Press Release container -->



<div class="PR-cont">

<div class="PR-header clearfix">

<h4 class="pull-left"><?=strip_tags($press_new_title_2);?></h4>

<div class="pull-right"><?=strip_tags($press_new_date_2);?></div>

</div>

<?=$press_new_content_2;?>

</div>	<!-- end Press Release container -->



<div class="PR-cont">

<div class="PR-header clearfix">

<h4 class="pull-left"><?=strip_tags($press_new_title_3);?></h4>

<div class="pull-right"><?=strip_tags($press_new_date_3);?></div>

</div>

<?=$press_new_content_3;?>

</div>	<!-- end Press Release container -->



</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>