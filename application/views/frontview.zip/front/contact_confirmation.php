<div id="page_body">
<div class="inner">
<h1>Contact Us Confirmation</h1>
<?=$content;?>

</div>	<!-- end body contents -->
</div>	<!-- end page body here -->
