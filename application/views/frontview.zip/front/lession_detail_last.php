<div id="page-body">

<div class="container">


<div class="row-fluid inner-content">

<!--section left -->
<div class="span12 inner-contents">
<h2><span><img src="<?=base_url();?>images/front/lesson-detail-ico.png" width="27" height="27" alt=""> Lesson Detail</span></h2>
<h3 class="uppercase">LAST SLIDE </h3>

<h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h3>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam venenatis elit enim, vitae dictum lacus dapibus et. Donec lacinia commodo odio, non rhoncus sem adipiscing id. Curabitur eros dolor, lacinia hendrerit lorem euismod, aliquam consequat risus. Nam semper lacus metus, tincidunt cursus nisi elementum ut. Phasellus eleifend nulla id tristique semper. Curabitur pretium consequat tortor sit amet hendrerit. </p>

<ul class="arrow-list">
<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </li>

<li>Nam venenatis elit enim, vitae dictum lacus dapibus et. Donec lacinia commodo odio, non rhoncus sem adipiscing id.</li> 

<li>Curabitur eros dolor, lacinia hendrerit lorem euismod, aliquam consequat risus. Nam semper lacus metus,</li> 

<li>Phasellus eleifend nulla id tristique semper. Curabitur pretium consequat tortor sit amet hendrerit.</li> 
</ul>
<div class="table">
<div class="span4 left-clear pull-left"><img src="<?=base_url();?>images/front/lesson-image-placeholder.jpg" alt="" class="img-polaroid"></div>
<div class="span4 padding-left"><img src="<?=base_url();?>images/front/lesson-video-placeholder.jpg" alt="" class="img-polaroid"></div>
<div class="clear"></div>
</div>

<div class="row-fluid">
<h6 class="border-title"><span>Contributed by</span></h6>

<ul class="list-one-half">
<li><span>Author Name:</span> Lorem Ipsum</li>
<li><span>Title/Position:</span> Lorem Ipsum</li>
<li><span>Social Link:</span> <a href="#">www.Facebook.com/index.php?</a></li>
<li><span>URL:</span> <a href="#">www.Lorem Ipsum.com/index.php?</a></li>
</ul>
<div class="clear"></div>
<div class="devider-line table"></div>

<div class="bottom-three-links last-slide-links"><div class="pull-left"><button><strong>This Lesson Was Irrelevant?</strong></button> <button><strong>This Lesson Needs Improvement?</strong></button></div>
<div class="page-navi pull-right" style="padding-top: 0;">
<a href="#" class="navi-arrow"><img src="<?=base_url();?>images/front/left-slide-arrow.png" width="22" height="35" alt=""></a>
<a href="#">1</a>
<a href="#">2</a>
<a href="#">3</a>
</div>
<div class="clear"></div
></div>
<div class="last-comment-detail">
<textarea name="">Leave us your comment on lesson relevance and quality.</textarea>
<a href="#" class="close-link"><img src="<?=base_url();?>images/front/comment-close.png" width="31" height="32" alt=""></a>
</div>

<div class="clear"></div>
</div>
<div class="row-fluid last-slide-bottom">
<div class="pull-left">
<p>Share This Lesson With My Friends</p>
<p><a href="#"><img src="<?=base_url();?>images/front/email-ico.gif" width="39" height="35" alt=""></a> <a href="#"><img src="<?=base_url();?>images/front/facebook-ico.gif" width="39" height="35" alt=""></a> <a href="#"><img src="<?=base_url();?>images/front/twitter-ico.gif" width="39" height="35" alt=""></a> <a href="#"><img src="<?=base_url();?>images/front/linkedin-ico.gif" width="39" height="35" alt=""></a></p>
</div>
<div class="pull-right ="><a href="#" class="blue-button-flex">Get to Work</a> <a href="#" class="blue-button-flex">Go to My Main Account Area</a></div>

</div>
<!--/section left -->





</div>





<!--/content row -->

</div>

	<!-- end lesson detail -->





</div>

</div>

<!-- end page body -->

<div id="push"></div>