<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents clearfix">

<div class="clearfix frineds_title rscrh_ttl">

	<h2><span class="contact-ico rscrh_cat_icon">Resource Detail 
</span></h2>

<h3 class="pull-left">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h3>
    
    <div class="tp_cmnt pull-right">
    
    	<div class="anguls">
        	<a href="#"><img src="<?=base_url();?>images/front/angul_down.png" alt="low"></a>
            <span>17</span>
        </div>
        
        <div class="anguls">
        	<a href="#"><img src="<?=base_url();?>images/front/angul_up.png" alt="low"></a>
            <span>127</span>
        </div>
        
    </div>
        
</div>
<!--  end friend title  -->
<div class="resource_detail_container">

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam venenatis elit enim, vitae dictum lacus dapibus et. Donec lacinia commodo odio, non rhoncus sem adipiscing id. Curabitur eros dolor, lacinia hendrerit lorem euismod, aliquam consequat risus. Nam semper lacus metus, tincidunt cursus nisi elementum ut. Phasellus eleifend nulla id tristique semper. Curabitur pretium consequat tortor sit amet hendrerit. </p>

<p><span><a href="#"><img src="<?=base_url();?>images/front/Untitled-1_03.png" alt=" "></a></span> <a href="#">www.Lorem Ipsum.com/index.php?</a></p>

<div class="img_rdtl clearfix">

<span class="pinn_it_cont pull-left">
<img class="img_brdr" alt="image" src="<?=base_url();?>images/front/blog_detial_lrg1.jpg">
<a class="pinn_icon" href="#"><img src="<?=base_url();?>images/front/pinn_it_icon.jpg" alt="pinn"></a>
</span>

<img class="img_brdr pull-left" alt="image" src="<?=base_url();?>images/front/blog_detial_lrg2.jpg">

<div class="social_links_left">
    <a href="javascript:void(0);" onClick="openForm('<?=site_url('resource/facebook');?>')"><img src="<?=base_url();?>images/front/fb_medium.png" alt="fb"></a>
    <a href="javascript:void(0);" onClick="openForm('<?=site_url('resource/twitter');?>')"><img src="<?=base_url();?>images/front/twt_medium.png" alt="twt"></a>
    <a href="javascript:void(0);" onClick="openForm('<?=site_url('resource/email');?>')"><img src="<?=base_url();?>images/front/email_medium.png" alt="email"></a>
    <a href="#"><img src="<?=base_url();?>images/front/in_medium.png" alt="in"></a>
</div>

</div>

<div class="sbmt_dv">
<a href="#" class="back_btn"><img src="<?=base_url();?>images/front/back_btn.png" alt="back"></a>
<a href="javascript:void(0);" onClick="$('.rscrh_comment_box').show();" class="noraml_btn" style="margin-top:-4px;">Comment</a>

<div class="comment_box rscrh_comment_box" style="display:none">

<div class="arrow"></div>

<form action="#" method="get">
    	
    <label>Comment</label>
    
    <textarea class="input_field"></textarea>
    
    <div class="comment_sbmt_dv">
        <input name="" type="button" value="Post" class="custom-btn" />&nbsp;
        <input name="" type="button" value="Cancel" class="custom-btn" />
    </div>
    
    
    
</form>
</div>

</div>

</div>
<!--  end resource d c  -->

</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>