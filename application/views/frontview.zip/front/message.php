<div id="page-body">

<div class="container">



<!--message center -->
<div class="inner-contents">
<div class="message-center">
<div class="row">

<div class="span12">
<h2><span><img src="<?=base_url();?>images/front/message-center-ico.gif" alt=""> Message Center</span></h2>
</div>

</div>
<!--/row -->
<ul class="message-tabs">
<li class="active"><a href="#">Inbox</a></li>
<li><a href="#">Send a Message</a></li>
</ul>
<div class="clear"></div>
<!--message content -->
<div class="inbox-content">
<table style="width: 100%;">
  <tr>
  <th style="background: none; width: 1%;" scope="col">&nbsp;</th>
    <th style="width: 10%;" scope="col">Date</th>
    <th style="width: 1%;" scope="col">&nbsp;</th>
    <th style="width: 20%;" scope="col">From</th>
    <th style="width: 2%;" scope="col">&nbsp;</th>
    <th style="width: 58%;" class="hidden-phone" scope="col">Subject</th>
    <th style="width: 1%;" scope="col">&nbsp;</th>
    <th style="width: 5%;" scope="col">Actions</th>
    <th style="background: none; width: 2%;" scope="col">&nbsp;</th>
    
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td>11/11/2012</td>
    <td>&nbsp;</td>
    <td><img src="<?=base_url();?>images/front/sender-image.png" width="43" height="43" alt="" class="hidden-phone"> Lorem Ipsum</td>
    <td>&nbsp;</td>
    <td class="hidden-phone"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum.</strong></td>
    <td>&nbsp;</td>
    <td><a href="#"><img src="<?=base_url();?>images/front/refresh-button.png" width="22" height="22" alt="Reply" title="Reply"></a> <a href="#"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt="Close" title="Close"></a></td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td>11/11/2012</td>
    <td>&nbsp;</td>
    <td><img src="<?=base_url();?>images/front/sender-image.png" width="43" height="43" alt="" class="hidden-phone"> Lorem Ipsum</td>
    <td>&nbsp;</td>
    <td class="hidden-phone"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum.</strong></td>
    <td>&nbsp;</td>
    <td><a href="#"><img src="<?=base_url();?>images/front/refresh-button.png" width="22" height="22" alt="Reply" title="Reply"></a> <a href="#"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt="Close" title="Close"></a></td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td>11/11/2012</td>
    <td>&nbsp;</td>
    <td><img src="<?=base_url();?>images/front/sender-image.png" width="43" height="43" alt="" class="hidden-phone"> Lorem Ipsum</td>
    <td>&nbsp;</td>
    <td class="hidden-phone"><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum.</strong></td>
    <td>&nbsp;</td>
    <td><a href="#"><img src="<?=base_url();?>images/front/refresh-button.png" width="22" height="22" alt="Reply" title="Reply"></a> <a href="#"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt="Close" title="Close"></a></td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
    <td>11/11/2012</td>
    <td>&nbsp;</td>
    <td><img src="<?=base_url();?>images/front/sender-image.png" width="43" height="43" alt="" class="hidden-phone"> Lorem Ipsum</td>
    <td>&nbsp;</td>
    <td class="hidden-phone">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum.</td>
    <td>&nbsp;</td>
    <td><a href="#"><img src="<?=base_url();?>images/front/refresh-button.png" width="22" height="22" alt="Reply" title="Reply"></a> <a href="#"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt="Close" title="Close"></a></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>11/11/2012</td>
    <td>&nbsp;</td>
    <td><img src="<?=base_url();?>images/front/sender-image.png" width="43" height="43" alt="" class="hidden-phone"> Lorem Ipsum</td>
    <td>&nbsp;</td>
    <td class="hidden-phone">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum.</td>
    <td>&nbsp;</td>
    <td><a href="#"><img src="<?=base_url();?>images/front/refresh-button.png" width="22" height="22" alt="Reply" title="Reply"></a> <a href="#"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt="Close" title="Close"></a></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>11/11/2012</td>
    <td>&nbsp;</td>
    <td><img src="<?=base_url();?>images/front/sender-image.png" width="43" height="43" alt="" class="hidden-phone"> Lorem Ipsum</td>
    <td>&nbsp;</td>
    <td class="hidden-phone">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum.</td>
    <td>&nbsp;</td>
    <td><a href="#"><img src="<?=base_url();?>images/front/refresh-button.png" width="22" height="22" alt="Reply" title="Reply"></a> <a href="#"><img src="<?=base_url();?>images/front/close-button.png" width="22" height="22" alt="Close" title="Close"></a></td>
    <td>&nbsp;</td>
  </tr>
</table>

</div>
<!--/message content -->

</div>
</div>
<!--/message center -->


</div>

</div>	<!-- end page body -->

<div id="push"></div>