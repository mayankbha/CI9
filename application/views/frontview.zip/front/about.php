<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents">

<div class="text-center" style="text-align:center;font-size:40px;font-weight:bold;color:#3C638F;padding:15px 0 25px">Who We Are<br>and<br>Why We Do What We Do</div>

<?=str_replace('<img', '<img class="img_brdr pull-left" style="margin:5px 20px 20px 0"',$content);?>



</div>

</div>

</div>

</div>

</div>