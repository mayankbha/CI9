
	<div id="popover">
	
		<div id="popover-head" class="clearfix">
		
			<div class="span3"><img src="<?=base_url();?>/images/front/popup-logo.png" alt=" "></div>
			
			<div class="close-pp"><a href="javascript:void(0)" onClick="closePP();">Close (<strong>x</strong>)</a></div>
		
		</div>	<!-- end popover head -->
		
		
		
		<div id="popover-body">
		
			<div class="confirm-mascot"></div>
			
			<div class="signup-confirmmsg"><?=$content;?></div>
			
			<div class="text-center"><a href="javascript:void(0)" onClick="closePP();" class="btn-link">Close</a></div>
		
		</div>	<!-- end popver body -->
	
	</div>
