<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents clearfix">

<div class="clearfix frineds_title">

	<h2 class="pull-left"><span class="contact-ico friend_h2icon">Friends</span></h2>
    
    <div class="inpt_div_srch pull-left">
    	<input name="" type="text" class=" input_field" value="Search here" />
    	<input name="" type="image" src="<?=base_url();?>images/front/srch_btn.png" alt="search" class="search_btn" />
  	</div>
    
    <div class="pull-right">
    	<a href="#"><img src="<?=base_url();?>images/front/invite_friends.png" alt="invite"></a>
        <a href="#"><img src="<?=base_url();?>images/front/invite_friends_fb.png" alt="invite"></a>
    </div>
    
</div>
<!--  end friend title  -->

<div class="friend_container fd_container clearfix">

<div class="friend_box friend_detail_left clearfix">

  <img src="<?=base_url();?>images/front/frnd_detail_img.png" alt="friend" class="pull-left">
  
  <div class="pull-right">
  
  	<div class="fd_ttl">
     <p><span>First Name:</span>	Lorem</p>
     <p><span>Last Name:</span>	Ipsum</p>
    </div>
    
    <div class="fd_scl">
    	<p><img src="<?=base_url();?>images/front/fb_letter_icon.png" alt="fb"> <a href="#">www.facebook.com/lorem.p..</a></p>
        <p><img src="<?=base_url();?>images/front/twt_icon.png" alt="twitter"> <a href="#">www.Twitter.com/lorem.php?</a></p>
        <p><img src="<?=base_url();?>images/front/in_icon.png" alt="in"> <a href="#">www.Linkedin.com/lorem.ph..</a></p>
    </div>
  
  </div>
  
</div>
<!--  end friend box  -->

<div class="friend_box friend_detail_mdl clearfix">
    
    <div class="fd_ttl">
     <h3><img src="<?=base_url();?>images/front/info_icon.png" alt="info"> Information</h3>
    </div>
    
    <div class="fd_scl">
     <p><span>Email Address:</span>	Lorem@Ipsum.com</p>
     <p><span>Phone Number:</span>	0000 000 000</p>
     <p><span>Company Name:</span>	Lorem Ipsum LTD</p>
     <p><span>Website:</span>	WWW.LoremIpsum.com</p>
    </div>
    
</div>
<!--  end friend box  -->


<div class="friend_box friend_detail_mdl friend_detail_rgt clearfix">
    
    <div class="fd_ttl">
     <h3><img src="<?=base_url();?>images/front/about_icon.png" alt="about"> About</h3>
    </div>
    
    <p class="fd_aboutp">
    	Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and 
    </p>
    
</div>
<!--  end friend box  -->

<div class="clear"></div>

<div style="padding-top:10px;">
<a href="#"><img src="<?=base_url();?>images/front/msg_btn.png" alt="message"></a>
<a href="#"><img src="<?=base_url();?>images/front/atf_btn.png" alt="add to friend"></a>
</div>

</div>
<!--  end friend container  -->

</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>