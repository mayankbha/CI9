<!DOCTYPE HTML>

<html>



<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Welcome to Our Site!</title>

<link href="<?=base_url();?>css/front/reset.css" rel="stylesheet" type="text/css" />

<link href="<?=base_url();?>css/front/bootstrap.min.css" rel="stylesheet" type="text/css" />

<link href="<?=base_url();?>css/front/my_style.css" rel="stylesheet" type="text/css" />

<link href="<?=base_url();?>css/front/popup.css" rel="stylesheet" type="text/css" />

<link href="<?=base_url();?>css/front/custom-responsive.css" rel="stylesheet" type="text/css" />

<link href="<?=base_url();?>css/front/bootstrap-responsive.css" rel="stylesheet" type="text/css" />



<!-- HTML5 shim for IE backwards compatibility -->

<!--[if lt IE 9]>

<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>

<![endif]-->



</head>



<body>



<!-- main wrapper starts here -->

<div id="popover-wrapper" style="max-height: 100%;">

<div id="popover" style="max-width: 815px;">



<div id="popover-head" class="clearfix">

<div class="span3"><img src="<?=base_url();?>images/front/popup-logo.png" alt=" "></div>

<div class="close-pp"><a href="#">Close (<strong>x</strong>)</a></div>


</div>	<!-- end popover head -->



<div id="popover-body">
<div class="checklist-page">

<h2><img src="<?=base_url();?>images/front/poopup-checklist.gif" width="25" height="26" alt=""> Checklist</h2>
<div style="padding-bottom: 15px;">
<h3><span class="pull-left">How to create amaizing facebook compaigns</span><span class="pull-right">14/14</span></h3>
<div class="clear"></div>
</div>

<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam venenatis elit enim, vitae dictum lacus dapibus et. Donec lacinia commodo odio, non rhoncus sem adipiscing id. Curabitur eros dolor, lacinia hendrerit lorem euismod, aliquam consequat risus. Nam semper lacus metus, tincidunt cursus nisi elementum ut.</p>

<div class="checkout-list">

<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
<p><input name="" type="checkbox" value=""><label>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </label></p>
</div>

<div class="checklist-devider"><button class="blue-button-large">I’m Done With My First Comaign! Next!</button></div>

<p>Complete the Checklist NOW! Or use the button below to add your compagn to your TO DO list and the Checklist to your Checklist Library + Keep Learning:</p>

<div class="checklist-devider text-center"><button class="next-lesson-button">Take Me to My Next Lesson!</button></div>
<div class="bottom-three-links"><button>Was This Lesson Irrelevant?</button> <button>Was This Entire Lesson Bad?</button> <button>How Could It be Improved?</button></div>


</div>

</div>	<!-- end popver body -->



</div>

</div>	<!-- main wrapper ends here -->



<!-- bootstrap js files -->

<script src="http://code.jquery.com/jquery.js" type="text/jscript"></script>

<script src="<?=base_url();?>js/bootstrap.min.js" type="text/jscript"></script>

</body>

</html>