<div id="page-body">

<div class="container">


<div class="row-fluid inner-content">
<!--section left -->
<div class="span12 inner-contents">
<?php /*?><h2 style="padding-bottom: 13px;"><span><img src="<?=base_url();?>images/front/surveys-ico.gif" width="28" height="29" alt=""> View Survey Detail </span></h2><?php */?>


<h3 style="padding-bottom: 25px">Lorem ipsum dolor sit amet, consectetur adipiscing elit?</h3>

<div class="radio-group">
<ul>
<li class="highlight"><label class="radio">
<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non sem ut tortor porttitor a a libero.
</label></li>

<li><label class="radio">
<input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
Proin placerat, risus at ultrices euismod, justo orci cursus elit.
</label></li>

<li><label class="radio">
<input type="radio" name="optionsRadios" id="optionsRadios3" value="option2">
Proin placerat, risus at ultrices euismod, justo orci cursus elit.
</label></li>

<li><label class="radio">
<input type="radio" name="optionsRadios" id="optionsRadios4" value="option2">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent non sem ut tortor.
</label></li>
</ul>
</div>
<div class="span8" style="margin: 50px auto; float: none;"><a href="#" class="blue-button-fullwidth"><span>Next <img src="<?=base_url();?>images/front/next-arrow.png" width="25" height="22" alt=""></span></a></div>
<div class="hidden-phone" style="padding-bottom: 597px;"></div>









</div>
<!--/section left -->



</div>





<!--/content row -->

</div>

	<!-- end lesson detail -->





</div>

</div>

<!-- end page body -->

<div id="push"></div>
