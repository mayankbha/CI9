<div id="page-body" class="logged-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="banner_container">
<div class="blog_banner rscrch_banner clearfix">

<div class="rscrs_banner_left pull-left text-right">
	<img src="<?=base_url();?>images/front/rscrs_cat_img.png" alt=" "> 
</div>

<div class="rscrs_banner_right pull-left text-center">

<h5>Our Favorite Small Business Resources</h5>

<?=$content;?>

</div>

</div>
</div>
<!--  end blog banner  -->



<div class="inner-contents clearfix">


<div class=" row-fluid clearfix">

<h2 class="pull-left" style="margin-bottom:0px;"><span class="resources-ico">Resources</span></h2>

<div class="search-filter" style="padding:0;">

<input name="" type="text" class="search-field" value="Search">

<input name="" type="image" src="<?=base_url();?>images/front/search-btn.png" alt="Search">

</div>

</div>



<div id="resources-list" style="padding-top:10px;">

<ul>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="even">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



<li class="odd">

<div class="list-inner clearfix">

<div class="pull-left"><a href="#">Resource Category Title Goes Here</a></div>

<div class="pull-right"><a href="#"><img src="<?=base_url();?>images/front/pointer.png" alt=" "></a></div>

</div>

</li>



</ul>

</div>	<!-- end resources list -->



</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>
