<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents clearfix">

<div class="clearfix frineds_title">

	<h2 class="pull-left"><span class="contact-ico rscrh_cat_icon">Resource Category 
</span></h2>
    
    <div class="inpt_div_srch pull-right">
    	<input name="" type="text" class=" input_field" value="Search" />
    	<input name="" type="image" src="<?=base_url();?>images/front/srch_btn.png" alt="search" class="search_btn" />
  	</div>    
</div>
<!--  end friend title  -->

<a href="#" class="back_btn"><img src="<?=base_url();?>images/front/back_btn.png" alt="back"></a>

<div class="resource_cat_container clearfix">

<div class="rc_cont friend_box">
	<h3><span>Resource Title Goes Here</span></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus. Suspendisse potenti. Nam a quam sem. Donec sodales  ut erat hendrerit volutpat. Quisque ut lobortis nulla. Mauris  egestas nulla, quis mollis purus. Integer eget dictum ipsum. Pellentesque velit felis, fringilla eget dolor eget, pharetra tincidunt eros. </p>
</div>

<div class="rc_cont friend_box">
	<h3><span>Resource Title Goes Here</span></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus. Suspendisse potenti. Nam a quam sem. Donec sodales  ut erat hendrerit volutpat. Quisque ut lobortis nulla. Mauris  egestas nulla, quis mollis purus. Integer eget dictum ipsum. Pellentesque velit felis, fringilla eget dolor eget, pharetra tincidunt eros. </p>
</div>

<div class="rc_cont friend_box">
	<h3><span>Resource Title Goes Here</span></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus. Suspendisse potenti. Nam a quam sem. Donec sodales  ut erat hendrerit volutpat. Quisque ut lobortis nulla. Mauris  egestas nulla, quis mollis purus. Integer eget dictum ipsum. Pellentesque velit felis, fringilla eget dolor eget, pharetra tincidunt eros. </p>
</div>

<div class="rc_cont friend_box">
	<h3><span>Resource Title Goes Here</span></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus. Suspendisse potenti. Nam a quam sem. Donec sodales  ut erat hendrerit volutpat. Quisque ut lobortis nulla. Mauris  egestas nulla, quis mollis purus. Integer eget dictum ipsum. Pellentesque velit felis, fringilla eget dolor eget, pharetra tincidunt eros. </p>
</div>

<div style="height:10px;">&nbsp;</div>
</div>
<!--  end resource category  -->

<a href="#" class="back_btn has_margin_top"><img src="<?=base_url();?>images/front/back_btn.png" alt="back"></a>


</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>