<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents">

<h2><span class="terms-ico">Terms of Use</span></h2>

<?=$content;?>



</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>