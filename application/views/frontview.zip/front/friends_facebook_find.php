<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents clearfix">

<div class="clearfix frineds_title">

	<h2 class="pull-left"><span class="contact-ico friend_h2icon">Friends</span></h2>
    
    <div class="inpt_div_srch pull-left">
    	<input name="" type="text" class=" input_field" value="Search here" />
    	<input name="" type="image" src="<?=base_url();?>images/front/srch_btn.png" alt="search" class="search_btn" />
  	</div>
    
    <div class="pull-right">
    	<a href="#"><img src="<?=base_url();?>images/front/invite_friends.png" alt="invite"></a>
        <a href="#"><img src="<?=base_url();?>images/front/invite_friends_fb.png" alt="invite"></a>
    </div>
    
</div>
<!--  end friend title  -->

<div class="friend_container">

<div class="friend_box clearfix">
    <img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
    <h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

</div>
<!--  end friend container  -->

</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>