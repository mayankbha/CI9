<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="blog_inner_container">

<div class="blog_container_left inner-contents pull-left">

<h2 style="margin:0 0 15px;"><span class="contact-ico blog_ico">The Startup MEOW Small Business Blog</span></h2>

<div class="bcl_parts blog_bg_box clearfix">

	<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
    
    <img src="<?=base_url();?>images/front/img_ph_lrg.jpg" alt="image" class="img_brdr pull-left">
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus.</p>
    
    <div class="read_more">
    	<a href="#" class="noraml_btn">Read More</a>       
    </div>
    
    <div class="social_links_left">
    	<a href="#"><img src="<?=base_url();?>images/front/fb_medium.png" alt="fb"></a>
        <a href="#"><img src="<?=base_url();?>images/front/twt_medium.png" alt="twt"></a>
        <a href="#"><img src="<?=base_url();?>images/front/email_medium.png" alt="email"></a>
        <a href="#"><img src="<?=base_url();?>images/front/in_medium.png" alt="in"></a>
    </div>
    
</div>
<!--  end bcl  -->

<div class="bcl_parts blog_bg_box clearfix">

	<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
    
    <img src="<?=base_url();?>images/front/img_ph_lrg.jpg" alt="image" class="img_brdr pull-left">
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus.</p>
    
    <div class="read_more">
    	<a href="#" class="noraml_btn">Read More</a>       
    </div>
    
    <div class="social_links_left">
    	<a href="#"><img src="<?=base_url();?>images/front/fb_medium.png" alt="fb"></a>
        <a href="#"><img src="<?=base_url();?>images/front/twt_medium.png" alt="twt"></a>
        <a href="#"><img src="<?=base_url();?>images/front/email_medium.png" alt="email"></a>
        <a href="#"><img src="<?=base_url();?>images/front/in_medium.png" alt="in"></a>
    </div>
    
</div>
<!--  end bcl  -->

<div class="bcl_parts blog_bg_box clearfix">

	<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
    
    <img src="<?=base_url();?>images/front/img_ph_lrg.jpg" alt="image" class="img_brdr pull-left">
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus.</p>
    
    <div class="read_more">
    	<a href="#" class="noraml_btn">Read More</a>       
    </div>
    
    <div class="social_links_left">
    	<a href="#"><img src="<?=base_url();?>images/front/fb_medium.png" alt="fb"></a>
        <a href="#"><img src="<?=base_url();?>images/front/twt_medium.png" alt="twt"></a>
        <a href="#"><img src="<?=base_url();?>images/front/email_medium.png" alt="email"></a>
        <a href="#"><img src="<?=base_url();?>images/front/in_medium.png" alt="in"></a>
    </div>
    
</div>
<!--  end bcl  -->

<div class="bcl_parts blog_bg_box clearfix">

	<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
    
    <img src="<?=base_url();?>images/front/img_ph_lrg.jpg" alt="image" class="img_brdr pull-left">
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis placerat feugiat, purus nibh tempor velit, non auctor libero augue in lorem. Proin eget ultrices risus.</p>
    
    <div class="read_more">
    	<a href="#" class="noraml_btn">Read More</a>       
    </div>
    
    <div class="social_links_left">
    	<a href="#"><img src="<?=base_url();?>images/front/fb_medium.png" alt="fb"></a>
        <a href="#"><img src="<?=base_url();?>images/front/twt_medium.png" alt="twt"></a>
        <a href="#"><img src="<?=base_url();?>images/front/email_medium.png" alt="email"></a>
        <a href="#"><img src="<?=base_url();?>images/front/in_medium.png" alt="in"></a>
    </div>
    
</div>
<!--  end bcl  -->

</div>
<!--  end left part  -->

<div class="blog_contaienr_right pull-right">

    <div class="blog_bg_box">
        <h4>Find Us:</h4>
        <div class="lrge_scl_blk">
            <a href="#"><img src="<?=base_url();?>images/front/fb_large.png" alt="fb"></a>
            <a href="#"><img src="<?=base_url();?>images/front/twt_large.png" alt="twt"></a>
            <a href="#"><img src="<?=base_url();?>images/front/g+_large.png" alt="email"></a>
            <a href="#"><img src="<?=base_url();?>images/front/rss_large.png" alt="in"></a>
            <a href="#"><img src="<?=base_url();?>images/front/in_large.png" alt="in"></a>
        </div>
    </div>
    <!-- end blog bg box -->

    <div class="br_separator"></div>

    <div class="blog_bg_box blr_p">
        <p>If you would like to contribute please email us at contribute@site.com</p>
    </div>
    <!-- end blog bg box -->

    <div class="br_separator"></div>

    <div class="blog_bg_box">
        <h4>Subscribe for Updates and Articles</h4>
        <div class="lrge_scl_blk">
            <div class="spa3"><input name="" type="text" class="input_field" value="email"></div>
            <input name="" type="button" class="noraml_btn" value="Subscribe">
        </div>
    </div>
    <!-- end blog bg box -->

    <div class="br_separator"></div>

    <div class="blg_rgt_btm_part blog_bg_box">

        <h4>Trending Articles</h4>

        <div class="brbp_box clearfix">

        <img src="<?=base_url();?>images/front/img_ph_sml.jpg" alt="image" class="img_brdr pull-left">
        
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante.</p>

        </div>
        <!-- end brbp -->

        <div class="brbp_box clearfix">

        <img src="<?=base_url();?>images/front/img_ph_sml.jpg" alt="image" class="img_brdr pull-left">
        
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante.</p>

        </div>
        <!-- end brbp -->

        <div class="brbp_box clearfix">

        <img src="<?=base_url();?>images/front/img_ph_sml.jpg" alt="image" class="img_brdr pull-left">
        
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante.</p>

        </div>
        <!-- end brbp -->

    </div>
    <!-- end blog right bottom -->

</div>
<!-- end right blog container -->

</div>
<!--  end blog container  -->

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>