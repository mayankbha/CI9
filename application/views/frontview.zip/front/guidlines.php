<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents">

<h2><span class="guidelines-ico">Guidelines</span></h2>

<?=$content;?>



</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>