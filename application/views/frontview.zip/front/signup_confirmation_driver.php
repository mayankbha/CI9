<div id="page_body">
<div class="inner">
<h1>Sign Up Confirmation <span>(Driver)</span></h1>
<?=$content?>
</div>	<!-- end body contents -->
</div>	<!-- end page body here -->
