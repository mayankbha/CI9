<div id="page-body">

<div class="container">
<div class="inner-contents">

<div class="row">

<div class="span12">
<h2><span><img src="<?=base_url();?>images/front/message-center-ico.gif" alt=""> Reply</span></h2>
</div>

</div>
<!--/row -->

<!--message center -->
<div class="message-center">
<ul class="message-tabs">
<li><a href="#">Inbox</a></li>
<li class="active"><a href="#">Send a Message</a></li>
</ul>
<div class="clear"></div>
<!--message content -->
<div class="inbox-content">
<div class="row-fluid">
<div class="message-form">
<form action="#" method="post">
<p style="padding-bottom: 15px;"><label>To:</label> Username</p>
<p><label>Subject:</label> <input name="" type="text" class="input-field" value="Re: Lorem ipsum dolor sit amet, consectetur adipiscing elit."></p>
<p><label>Message:</label> <textarea name="" class="input-field" style="height: 140px;">


***********************************************************************************************
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam venenatis elit enim, vitae dictum lacus dapibus et. Donec lacinia commodo odio, non rhoncus sem adipiscing id. Curabitur eros dolor, lacinia hendrerit lorem euismod, aliquam consequat ris.</textarea></p>
<p><span style="display: block;" class="text-center">
<button class="btn btn-primary" type="submit">Send</button>
<button class="btn btn-primary" type="submit">Cancel</button>
</span></p>
</form>
</div>
</div>
<!--/row -->

</div>
<!--/message content -->

</div>
<!--/message center -->
</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>