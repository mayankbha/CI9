<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents clearfix">

<div class="clearfix frineds_title">

	<h2 class="pull-left"><span class="contact-ico friend_h2icon">Friends</span></h2>
    
    <div class="inpt_div_srch pull-left">
    	<input name="" type="text" class=" input_field" value="Search here" />
    	<input name="" type="image" src="<?=base_url();?>images/front/srch_btn.png" alt="search" class="search_btn" />
  	</div>
    
    <div class="pull-right">
    	<a href="#"><img src="<?=base_url();?>images/front/invite_friends.png" alt="invite"></a>
        
        <div class="popup_container invite_friend_pp"> <a href="#"><img src="<?=base_url();?>images/front/invite_friends_fb.png" alt="invite"></a>

            <div class="popover bottom">

              <div class="arrow" style="right:165px;"></div>

              <div class="popover-inner">

                <div class="popover-content ">

                  <form action="#" method="get">
                  
                      <label style="margin-top:0;"><?php $friends_invit = getMetaContent('friends_email_invitiation_title'); echo $friends_invit['data']?></label>
                      <input name="" type="text" class=" input_field" value="" />

                      <label>Subject:</label>
                      <input name="" type="text" class=" input_field" value="<?php $fremail_subject_default = getMetaContent('friends_email_invit_subject_default'); echo strip_tags($fremail_subject_default['data'])?>" />

                      <label>Message:</label>
                      <textarea class="input_field" rows="10"></textarea>
                      
                      <div class="pp_btnss text-center">
                      	<input type="button" class="custom-btn" value="Invite" name="">
                        <input type="button" class="custom-btn" value="Cancel" name="">
                      </div>

                  </form>

                </div>

              </div>

            </div>

          </div>
    </div>
    
</div>
<!--  end friend title  -->

<div class="friend_container">

<div class="friend_box clearfix">
    <img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
    <h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

<div class="friend_box clearfix">    
<img class="pull-left" src="<?=base_url();?>images/front/friends_face.png" alt="invite">
<h4>Lorem Ipsum Dolor</h4>
    <a href="#" class="crss_blue"><img src="<?=base_url();?>images/front/crss_blue.png" alt="invite"></a>
</div>
<!--  end friend box  -->

</div>
<!--  end friend container  -->

</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>
