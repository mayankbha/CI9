<div id="page-body">

<div class="container">

<div class="row">

<div class="span12">

<div class="inner-contents">

<h2><span>Apply To Become Partner</span></h2>



<div class="contact-form" style="padding-bottom:10px;">

<div class="row-fluid">



<div class="span6">

<div class=""><?=str_replace('<p>','',str_replace('</p>','',str_replace('<img','<img class="img_brdr" style="margin:15px 20px 0 0"',$image)));?></div>

<p style="padding-top:15px;"></p>
<?=$content;?>

</div>	<!-- end left container -->



<div class="span6">

<form>

<p>

<strong>Name:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Company:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Email:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Subject:</strong>

<input name="" type="text" class="input_field">

</p>



<p>

<strong>Message:</strong>

<textarea name="" cols="10" rows="10" class="input_field"></textarea>

</p>



<div class="submit text-center">

<input name="" type="button" class="custom-btn" value="<?php $parteners_button_submit = getMetaContent('parteners_button_submit'); echo strip_tags($parteners_button_submit['data']);?>" style="background:url(<?=base_url();?>images/front/btn-large2.png) no-repeat scroll left top;width:225px;font-size: 14px !important;">

<input name="" type="button" class="custom-btn" value="Cancel">

</div>

</form>

</div>	<!-- end right container -->



</div>

</div>	<!-- end container form -->



<h2><span>Partners</span></h2>



<div class="row-fluid">



<div class="span6">

<div class="partners clearfix">

<div class="partner-logo"><img src="<?=base_url();?>images/front/partner-logo.jpg" alt=" "></div>

<div class="partner-desc">

<span class="pr-title">Partner Lorem Ipsum Dolor</span>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis.</p>

</div>

</div>

</div>



<div class="span6">

<div class="partners clearfix">

<div class="partner-logo"><img src="<?=base_url();?>images/front/partner-logo.jpg" alt=" "></div>

<div class="partner-desc">

<span class="pr-title">Partner Lorem Ipsum Dolor</span>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis.</p>

</div>

</div>

</div>



</div>



<div class="row-fluid">



<div class="span6">

<div class="partners clearfix">

<div class="partner-logo"><img src="<?=base_url();?>images/front/partner-logo.jpg" alt=" "></div>

<div class="partner-desc">

<span class="pr-title">Partner Lorem Ipsum Dolor</span>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis.</p>

</div>

</div>

</div>



<div class="span6">

<div class="partners clearfix">

<div class="partner-logo"><img src="<?=base_url();?>images/front/partner-logo.jpg" alt=" "></div>

<div class="partner-desc">

<span class="pr-title">Partner Lorem Ipsum Dolor</span>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras a fermentum ipsum. Phasellus faucibus odio ante, vitae pulvinar tortor elementum in. Nulla varius, tortor quis.</p>

</div>

</div>

</div>



</div>



</div>

</div>

</div>

</div>

</div>	<!-- end page body -->

<div id="push"></div>