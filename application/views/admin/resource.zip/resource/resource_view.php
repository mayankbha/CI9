<h2><span>Admin</span> View a Resource </h2>

<div class="ymp_content ymp_view_resources">

    <div class="yvr_block pull-left span5" style="margin-left:0;">
        <strong>Name:</strong> <span><?php echo $resource->name; ?></span>
    </div>

    <div class="yvr_block pull-left span4">
        <strong>Category:</strong> <span><?php echo $resource->name; ?></span>
    </div>

    <div class="clearfix"></div>

    <div class="yvr_block">
        <strong style="display:block;">Text:</strong>
        <span><?php echo $resource->text; ?></span>
    </div>

    <div class="yvr_block">
        <img src="<?php echo base_url() ?>images/<?php echo $resource->image; ?>" alt=" " class="img_brdr_sdw">
        <img src="<?php echo base_url() ?>images/<?php echo $resource->video; ?>" alt=" " class="img_brdr_sdw">
    </div>

    <div class="yvr_block">
        <strong>Link:</strong> <a href="<?php echo $resource->url;  ?>"><?php echo $resource->url; ?></a>
    </div>

    <div class="sbmt_dv" >

        <button class="btn" type="submit"  onclick="window.location='<?php echo site_url('admin/resource'); ?>';" >Back</button>
        &nbsp;

        <button class="btn" type="submit"  onclick="window.location='<?php echo site_url('admin/resource/edit/' . $resource->id); ?>';">Edit</button>
        &nbsp;

       <div class="popup_container"  ><a href="#!delete" class="delete_confirm"> <button class="btn" type="submit" >Remove</button></a>

                                        <div class="popover bottom" style="display:none;">
                                            <div class="arrow"></div>
                                            <div class="popover-inner">
                                                <div class="popover-content">
                                                    <p> Are you sure you want to do this?
                                                        <span>This action can not be undone! </span> <span
                                                            class="sp_btn">
										<button type="button"
                                                data-target-url="<?php echo site_url('admin/resource/delete/' . $resource->id); ?>"
                                                class="go_to btn ymp_btn_lrge ymp_btn_small">Confirm
                                        </button>
										<button type="submit" class="btn ymp_btn_lrge ymp_btn_small delete">Cancel
                                        </button>
										</span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>





        <!--<button class="btn" type="submit"  onclick="window.location='<?php //echo site_url('admin/resource/delete/' . $resource->id); ?>';">Remove</button>-->

    </div>

</div>