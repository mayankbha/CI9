<div id="page-body">

    <div class="container">

        <div class="row">

            <div class="span12">

                <h2 class="pull-left"><span>Admin</span> Resources Controller</h2>

                <div class="search_box search_box_with_drpdwn pull-left">

                    <form action="#" method="get">

                        <div class="srch_box pull-left">

                            <select name="fancySelect" class="sel_dropdown">

                                <option value="1" selected="selected">Category</option>

                                <option value="2">Cat1</option>

                                <option value="2">Cat2</option>

                                <option value="2">Cat3</option>

                            </select>

                        </div>

                        <div class="inpt_div_srch pull-left">

                            <input name="" type="text" class="ymp_inpt" value="Search here"/>

                            <input name="" type="image" src="<?php echo site_url('images/srch_icon.png'); ?>"
                                   alt="search" class="search_btn"/>

                        </div>

                    </form>

                </div>

                <div class="sort_by pull-left">

                    <label>Sort:</label>

                    <select class="ymp_inpt">

                        <option>By Level</option>

                    </select>

                </div>

                <a href="<?php echo site_url('admin/resource/add'); ?>" class="ymp_top_btn pull-right">Create New
                    Resource</a>

                <div class="clear"></div>

                <div class="tabular_cont">

                    <table>
                        <thead>
                        <tr>
                            <th class=""><a
                                    href="<?php echo site_url('admin/resource/page/' . $page . '/name/' . $order) ?>"
                                    class="">
                                    Name <?php echo($orderBy == "slug" ? "<i class=\"sorting-" . $order . "\"></i>" : ""); ?></a>
                            </th>
                            <th class=""><a
                                    href="<?php echo site_url('admin/resource/page/' . $page . '/text/' . $order); ?>"
                                    class="">Description
                                    <?php echo($orderBy == "title" ? "<i class=\"sorting-" . $order . "\"></i>" : ""); ?></a>
                            </th>
                            <th class=""><a
                                    href="<?php echo site_url('admin/resource/page/' . $page . '/cat_id/' . $order); ?>"
                                    class="">Category
                                    <?php echo($orderBy == "title" ? "<i class=\"sorting-" . $order . "\"></i>" : ""); ?></a>
                            </th>

                            <th>Actions</th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php 
						foreach ($contents->result() as $content) { ?>
                            <tr>
                                <td class=""><a href="<?php echo site_url('admin/resource/view_resource/'.$content->id)?>"  style="color:#333333" ><?php echo $content->name; ?></a></td>
                                <td class="hidden-phone"><?php echo $content->text; ?></td>
                                <td class="hidden-phone"><?php echo $content->category_name; ?></td>
                                <td class="action"><a
                                        href="<?php echo site_url('admin/resource/edit/' . $content->id); ?>"><img
                                            src="<?php echo site_url('images/edit_icon.png'); ?>" alt=" "/></a>

                                    <div class="popup_container"><a href="#!delete" class="delete_confirm"><img
                                                src="<?php echo site_url('images/delete_icon.png'); ?>" alt=" "/></a>

                                        <div class="popover bottom" style="display:none;">
                                            <div class="arrow"></div>
                                            <div class="popover-inner">
                                                <div class="popover-content">
                                                    <p> Are you sure you want to do this?
                                                        <span>This action can not be undone! </span> <span
                                                            class="sp_btn">
										<button type="button"
                                                data-target-url="<?php echo site_url('admin/resource/delete/' . $content->id); ?>"
                                                class="go_to btn ymp_btn_lrge ymp_btn_small">Confirm
                                        </button>
										<button type="submit" class="btn ymp_btn_lrge ymp_btn_small delete">Cancel
                                        </button>
										</span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>