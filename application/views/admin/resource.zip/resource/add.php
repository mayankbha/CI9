<script>
jQuery(document).ready(function($){
function getFilename(file) {
  if (file.indexOf('/') > -1) file = file.substring(file.lastIndexOf('/') + 1);
  else if (file.indexOf('\\') > -1) file = file.substring(file.lastIndexOf('\\') + 1);
  return file;
}
	$('#inputUpload').change(function(){
		var _fileName=getFilename($('#inputUpload').val());
		if(_fileName!=""){
		$('#inputUploadFilename').val(_fileName);
		}
	})
	
	$('#inputUploadVideo').change(function(){
		var _fileName=getFilename($('#inputUploadVideo').val());
		if(_fileName!=""){
		$('#inputUploadFilenameVideo').val(_fileName);
		}
	})

})
</script>

<h2><span>Admin</span> Add/Edit a Resource</h2>

<div class="ymp_content form_div form_blog_edit edit_resources">

    <form class="form-horizontal" method="post" action="<?php echo site_url('admin/resource/add'); ?>">

        <div class="control-group">

            <label class="control-label">Name:</label>

            <div class="controls">

                <input type="text" class="span7 input_field" name="r_name" value="">

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Text:</label>

            <div class="controls">

                <textarea name="r_text" cols="10" rows="10" class="input_field span7"></textarea>

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Image:</label>

            <div class="controls">
				<input type="file" id="inputUpload" name="image" style="display:none" placeholder="">
				<label for="inputUpload">
					<input type="text" readonly="readonly" id="inputUploadFilename" class="input_field span6" />
					<button type="button" class="btn bt2  ymp_btn_lrge">Browse</button>
				</label>
			</div>

        </div>

        <div class="control-group">

            <label class="control-label">Video:</label>

           <div class="controls">
				<input type="file" id="inputUploadVideo" name="video" style="display:none" placeholder="">
				<label for="inputUploadVideo">
					<input type="text" readonly="readonly" id="inputUploadFilenameVideo" class="input_field span6" />
					<button type="button" class="btn bt1  ymp_btn_lrge">Browse</button>
				</label>
			</div>

        </div>

        <div class="control-group">

            <label class="control-label">URL:</label>

            <div class="controls">

                <input type="text" class="span7 input_field"
                       value="" name="r_url">

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Stage:</label>

            <div class="controls">

                <select name="r_stage" class="input_field span7">
                    <?php foreach ($lessons as $lesson): ?>
                        <option value="<?php echo $lesson->id ?>"><?php echo $lesson->stage;?></option>
                    <?php endforeach;?>
                </select>

            </div>

        </div>

        <div class="control-group">

            <label class="control-label spcl_lbl">Lesson/Survey:</label>

            <div class="controls spcl_cntrls">

                <select name="r_survey" class="input_field span7">
                    <?php foreach ($surveys as $survey) { ?>
                        <option value="<?php echo $survey->id; ?>"><?php echo $survey->stage;?></option>
                    <?php }?>
                </select>

            </div>

        </div>

        <div class="sbmt_dv">

            <button type="submit" class="btn " name="do_save_resource">Save</button>
            <input type="hidden" name="do_save_resource" value="do_save_content"/>

            &nbsp;

            <button type="submit" class="btn  ">Cancel</button>

        </div>

    </form>

</div>
