<h2><span>Admin</span> Add/Edit a Resource </h2>

<div class="ymp_content form_div form_blog_edit edit_resources">

    <form class="form-horizontal" method="post"
          action="<?php echo site_url('admin/resource/edit/' . $resource->id); ?>">

        <div class="control-group">

            <label class="control-label">Name:</label>

            <div class="controls">

                <input type="text" class="span7 input_field" name="r_name" value="<?php echo $resource->name; ?>">

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Text:</label>

            <div class="controls">

                <textarea name="r_text" cols="10" rows="10"
                          class="input_field span7"><?php echo $resource->text;?></textarea>

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Image:</label>

            <div class="controls">
                  <input type="file" id="inputUpload"   placeholder=""   class="btn   "   name="r_image">
                  <input type="hidden"  id="imageval"  name="imageval"  value="<?php echo $resource->image; ?>"   />
               <!-- <input type="text" class="span7 input_field" name="r_image"
                       value="<?php //echo $resource->image; ?>">-->

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Video:</label>

            <div class="controls">
                <input type="file" id="inputUpload"   placeholder=""   class="btn  "  name="r_video">
                <input type="hidden"  id="videoval"  name="videoval"  value="<?php echo $resource->video; ?>"   />
           <!--     <input type="text" class="span7 input_field"
                       value="<?php //echo $resource->video; ?>" name="r_video">-->

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">URL:</label>

            <div class="controls">

                <input type="text" class="span7 input_field"
                       value="<?php echo $resource->url; ?>" name="r_url">

            </div>

        </div>

        <div class="control-group">

            <label class="control-label">Stage:</label>

            <div class="controls">


                <select name="r_stage" class="input_field span7">
                    <?php foreach ($lessons as $lesson): if($lesson->id==$resource->lesson_id){ ?>
                        
                        <option value="<?php echo $lesson->id ?>"  selected="selected"><?php echo $lesson->stage;?></option>
                    <?php 
					      }else{
				    ?>
                        <option value="<?php echo $lesson->id ?>"  ><?php echo $lesson->stage;?></option>
                    <?php
					}
					endforeach;?>
                </select>
            </div>

        </div>

        <div class="control-group">

            <label class="control-label spcl_lbl">Lesson/Survey:</label>

            <div class="controls spcl_cntrls">

                <select name="r_survey" class="input_field span7">
                    <?php foreach ($surveys as $survey) { 
					  if($survey->id==$resource->survey_id){
					?>
                        <option value="<?php echo $survey->id; ?>"  selected="selected"><?php echo $survey->stage;?></option>
                    <?php 
					     }else{
					?>
					    <option value="<?php echo $survey->id; ?>"><?php echo $survey->stage;?></option>
					<?php 
						 }
					}?>
                </select>

            </div>

        </div>

        <div class="sbmt_dv">

            <button type="submit" class="btn " name="do_edit_resource">Save</button>
            <input type="hidden" name="do_edit_resource" value="do_edit_resource"/>

            &nbsp;

            <button type="submit" class="btn  ">Cancel</button>

        </div>

    </form>

</div>